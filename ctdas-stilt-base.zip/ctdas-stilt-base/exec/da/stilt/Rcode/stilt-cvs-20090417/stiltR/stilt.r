#Calls Trajecmod
#
#  $Id: stilt.r,v 1.5 2008/08/11 16:08:20 skoerner Exp $
#---------------------------------------------------------------------------------------------------

#
#get all required R fuctions
#
if (! exists("sourcepath")) {
   if (file.exists("stiltR"))
      sourcepath <- paste(getwd(), "/stiltR/", sep="")
   else if (file.exists("Rsc"))
      sourcepath <- paste(getwd(), "/Rsc/", sep="")
   else {
      stop('stilt.r: no stiltR or Rsc directory found.')
      quit(status=1)
   }
}
cat("stilt.r: using sourcepath", sourcepath, "\n")

if (! file.exists(paste(sourcepath, "sourceall.r", sep=""))) stop('stilt.r: "sourcepath" is not a valid source path')
source(paste(sourcepath,"sourceall.r",sep=""))

partinfo <- Sys.getenv(c("STILT_PART", "STILT_TOTPART"), unset = NA)	# get job partitioning info
if (any(is.na(partinfo))) {
   partarg    <- NULL
   totpartarg <- NULL
   nodeoffset <- NULL
} else {
   partarg    <- as.integer(partinfo[[1]])
   totpartarg <- as.integer(partinfo[[2]])
   nodeoffset <- NULL 	# not used yet
}
#Call Trajecmod function, store run info
run.info <- Trajecmod(partarg=partarg, totpartarg=totpartarg, nodeoffset=nodeoffset)

#save run.info to object with date and time in name
#example: ./Runs.done/setStiltparam.Mar..9.17:40:49.2004.r
savename <- gsub(" ",".",date())
savename <- substring(savename,4)
assignr(paste("run.info",savename,sep=""),run.info,"./Runs.done/",printTF=T)
