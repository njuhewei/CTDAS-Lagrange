motif<-function(...){
#For backward compatibility with older S scripts
#
#  $Id: motif.r,v 1.2 2007/06/27 11:54:03 skoerner Exp $
#---------------------------------------------------------------------------------------------------

X11(...)
}
