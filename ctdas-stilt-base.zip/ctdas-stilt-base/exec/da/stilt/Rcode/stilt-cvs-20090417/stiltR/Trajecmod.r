#***************************************************************************************************
# Function that loops over all starting times
#***************************************************************************************************

Trajecmod <- function(partarg=NULL, totpartarg=NULL, nodeoffset=NULL) {

#---------------------------------------------------------------------------------------------------
# Calls 'Trajec' for each starting time
# arguments assigned from call to setStiltparam.r
#
# $Id: Trajecmod.r,v 1.29 2008/08/12 09:29:41 skoerner Exp $
#---------------------------------------------------------------------------------------------------


# need to assign parameters; also save parameter setting in archive file with date in name
source("setStiltparam.r")
savename <- gsub(" ", ".", date())
savename <- substring(savename,4)
if (is.element("Runs.done",list.files(sourcepath))) {
   file.copy("setStiltparam.r", paste(sourcepath, "setStiltparam", savename, ".r", sep=""),
             overwrite=T)
} else {
    if (substring(path, nchar(path)-nchar("Runs.done"), nchar(path)) == "Runs.done/") {
       file.copy("setStiltparam.r", paste(path, "setStiltparam", savename, ".r", sep=""),
                 overwrite=T)
} else
   cat("No Runs.done directory; parameter information not saved\n")
}



totpart <- 1
if (!is.null(totpartarg)) {
  cat('resetting totpart=', totpart, ' to totpartarg=', totpartarg, '\n', sep='')
  totpart <- totpartarg
}
part <- 1
if (!is.null(partarg)) {
  cat('Using totpart=', totpart, ' resetting part=', part, ' to partarg=', partarg, '\n', sep='')
  part <- partarg
}
if (!is.null(nodeoffset)) {
  nummodel <- part+nodeoffset
  cat('Using nodeoffset= ', nodeoffset, ' ,results in nummmodel= ', nummodel, '\n', sep='')
} else {
  nummodel <- part
}



# get Starting info
if (!existsr(Timesname, path)) stop(paste("cannot find object ", Timesname, " in directory ", path, sep=""))
StartInfo <- getr(paste(Timesname, sep=""), path) # object containing fractional julian day, lat, lon, agl for starting position and time
# divide job into "totpart" parts to speed up
if (dim(StartInfo)[1] < totpart) {
  cat ('Warning: resetting totpart=', totpart, ' to dim(StartInfo)[1]=', dim(StartInfo)[1], '\n', sep='')
  totpart <- dim(StartInfo)[1]
}
if (part > totpart) {
  stop.message <- paste('Specified part=', part, ' > totpart=', totpart, ', stopping\n')
  cat(stop.message)
  stop(stop.message)
}
start.rows <- c(1 + (0:(totpart-1))*floor(dim(StartInfo)[1]/totpart), dim(StartInfo)[1]+1)
StartInfo <- StartInfo[start.rows[part]:(start.rows[part+1]-1),, drop=FALSE]
dimnames(StartInfo)[[2]] <- toupper(dimnames(StartInfo)[[2]])

if (biomassburnTF) {
   biomassburnoutmat <- matrix(nrow=dim(StartInfo)[[1]], ncol=2)
   dimnames(biomassburnoutmat) <- list(NULL, c("ident", "CO"))
}

# OVERWRITE WARNING
if(existsr(paste("stiltresult",part,sep=""),path=path)) {
   warning("You are attempting to overwrite an existing stiltresult object")
   warning("Notice: If you have changed parameters and Trajecmod fails, first try to move or remove the existing stiltresult object")
}


# SELECTION OF A FEW Receptors for testing!
if (Times.startrow > 0) StartInfo <- StartInfo[Times.startrow:Times.endrow,, drop=FALSE] # can be just one (Times.startrow=Times.endrow)

nrows <- length(StartInfo[,1]) # 1 row for each trajectory
rownum <- 1
firsttraj <- T
firstflux <- T
l.remove.Trajfile <- FALSE
if (exists('remove.Trajfile')) l.remove.Trajfile <- remove.Trajfile
for (j in 1:nrows) {

  ###############################################
  ##### run trajectories and save output ########
  ###############################################
  lat <- StartInfo[j, "LAT"]; lon <- StartInfo[j, "LON"]; agl <- StartInfo[j, "AGL"]
  identname <- pos2id(StartInfo[j,1], lat, lon, agl)
  cat("Trajecmod(): ", identname, " running at ", date(), "\n", sep="")
  dat <- month.day.year(floor(StartInfo[j,1])) # from julian to mmddyy
  yr4 <- dat$year # 4 digit year
  yr <- yr4%%100 # 2 digit year (or 1 digit...)
  mon <- dat$month
  day <- dat$day
  hr <- round((StartInfo[j,1]-floor(StartInfo[j,1]))*24)
  l.ziscale <- NULL
  if (exists('ziscale')) l.ziscale <- ziscale
  l.zsg.name <- NULL
  if (exists('zsg.name')) l.zsg.name <- zsg.name
  l.create.X0 <- FALSE
  if (exists('create.X0')) l.create.X0 <- create.X0
  info <- Trajec(yr=yr, mon=mon, day=day, hr=hr, lat=lat, lon=lon, agl=agl, nhrs=nhrs,
                 maxdist=stepsize, numpar=nparstilt, doublefiles=T, metd=metsource, metlib=metpath,
                 conv=convect, overwrite=overwrite, outpath=path, varsout=varstrajec, rundir=rundir,
                 nummodel=nummodel, sourcepath=sourcepath, ziscale=l.ziscale, zsg.name=l.zsg.name,
                 create.X0=l.create.X0)
  if (firsttraj) { # set up array for run info
    run.info <- matrix(NA, nrow=nrows, ncol=length(info))
    dimnames(run.info) <- list(NULL, names(info))
    firsttraj <- F
  } else {
    havenames <- dimnames(run.info)[[2]]
    for (nm in names(info)) {
      ndx <- which(havenames == nm)[1] # check if there are new column names
      if (is.na(ndx)) { # new column name, need to add column
        run.info <- cbind(run.info, rep(NA, dim(run.info)[1]))
        dimnames(run.info)[[2]][dim(run.info)[2]] <- nm
      } else { havenames[ndx] <- paste(havenames[ndx], "done", sep="")} # dummy
    }
  }
  run.info[j, names(info)] <- info


  #########################################################################
  ##### map trajectories to flux grids and vegetation maps ################
  ##### calculate mixing ratios at receptor points, save in result ########
  if (fluxTF) {
     print(paste("Trajecmod(): rownumber j:", j))


     traj <- Trajecvprm(ident=identname, pathname=path, tracers=fluxtracers, coarse=aggregation,
                dmassTF=T, nhrs=nhrs, vegpath=vegpath, evilswipath=evilswipath,
                vprmconstantspath=vprmconstantspath, vprmconstantsname=vprmconstantsname, nldaspath=nldaspath,
                nldasrad=usenldasrad, nldastemp=usenldastemp, pre2004=pre2004,
                keepevimaps=keepevimaps, detailsTF=detailsTF, bios=fluxmod, landcov=landcov,
                numpix.x=numpix.x, numpix.y=numpix.y, lon.ll=lon.ll, lat.ll=lat.ll,
                lon.res=lon.res, lat.res=lat.res)


     # 'traj' is a vector
     if (existsr(paste("stiltresult", part, sep=""), path=path)) {
        result <- getr(paste("stiltresult", part, sep=""), path=path)
        if (dim(result)[1] != nrows) {
           if (firstflux) print("Trajecmod(): existing stiltresult has wrong dimension; creating new one.")
        } else {
           if (firstflux) print("Trajecmod(): found existing stiltresult, update rows in that.")
           firstflux <- FALSE
        }
     }
     if (firstflux) { # at beginning create result object
        ncols <- length(traj) # all from Trajec(), + 3 from StartInfo (agl, lat, lon)
        result <- matrix(NA, nrow=nrows, ncol=ncols)
        firstflux <- F
     }
     result[rownum, ] <- traj
     dimnames(result) <- list(NULL, c(names(traj)))
     dimnames(result) <- list(NULL, dimnames(result)[[2]])
     # write the object into default database; object names are, e.g., "Crystal.1"
     assignr(paste("stiltresult", part, sep=""), result, path=path)
  }
  rownum <- rownum+1

  ##### calculate footprint, assign in object ########
  if (footprintTF) {
     print(paste("Trajecmod(): ", identname, " running footprint at ", unix("date"), sep=""))
     print(paste("Trajecmod(): memory in use:", memory.size()[1]))
     foot <- Trajecfoot(identname, pathname=path, foottimes=foottimes, zlim=c(zbot, ztop),
                        fluxweighting=NULL, coarse=1, vegpath=vegpath,
                        numpix.x=numpix.x, numpix.y=numpix.y,
                        lon.ll=lon.ll, lat.ll=lat.ll, lon.res=lon.res, lat.res=lat.res)
     assignr(paste("foot", identname, sep=""), foot, path)
     print(paste("Trajecmod(): foot", identname, " assigned", sep=""))
  } # if (exists(foottimes))

  ##### plot footprint ########
  if (footplotTF) { # plot footprints
    foot <- getr(paste("foot", identname, sep=""), path)
    footplot(foot,identname,lon.ll,lat.ll,lon.res,lat.res)
    for (foottimespos in 1:(length(foottimes)-1)) {
    ############# NOT READY YET ###############
    }
  }

  # Specify the function parameters
  if (biomassburnTF) {
     biomassburnoutmat[j, ] <- biomassburn(timesname=StartInfo, burnpath=burnpath, endpath=path, pathname=path, nhrs=nhrs, timesrow=j)
     print(paste("Biomassburning influence calculated to be ", biomassburnoutmat[j,2], " ppbv. Inserted into fireinfluence matrix row ", j, sep=""))
  }

  if(l.remove.Trajfile)unix(paste("rm -f ",paste(path,".RData",identname,sep=""),sep=""))

}                                                           # for (j in 1:nrows)


# Wrap up all of the CO biomassburning calculations
if (biomassburnTF)
  write.table(biomassburnoutmat, file=paste(path, "fireinfluencex", nhrs, "hr_", part, ".txt", sep=""), row.names=F)

##### save mixing ratios at receptor points in file, e.g. stiltresult1.csv for part=1 ########
if (fluxTF) {
   dimnames(result) <- list(NULL, dimnames(result)[[2]])
   # write the object into default database; object names are, e.g., "Crystal.1"
   assignr(paste("stiltresult", part, sep=""), result, path=path)
   print(paste("stiltresult", part, " assigned in ", path, sep=""))
   write.table(result, file=paste(path, "stiltresult", part, ".csv", sep=""), na="", row.names=F)
}

# If evi and lswi maps from vprm calculations is saved to the global environment; it should be removed here

rm(list=objects(pattern="GlobalEvi"), envir=globalenv())
rm(list=objects(pattern="GlobalLswi"), envir=globalenv())
gc(verbose=F)

return(run.info)

}

