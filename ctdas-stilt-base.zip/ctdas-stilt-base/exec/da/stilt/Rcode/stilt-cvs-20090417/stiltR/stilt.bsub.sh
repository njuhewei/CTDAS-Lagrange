#!/bin/bash
#
#---------------------------------------------------------------------------------------------------
#  Purpose
#
#  Script for distributing a STILT run on multiple processors using the LSF queueing system.
#
#---------------------------------------------------------------------------------------------------
#  History
#
#  07/18/2008  Initial version. Stefan Koerner
#
#  $Id: stilt.bsub.sh,v 1.1 2008/08/11 16:08:20 skoerner Exp $
#---------------------------------------------------------------------------------------------------

if [[ "$1" == "" || "$2" == "" || "$3" == "" ]]; then
   echo need 3 arguments: start part, end part, total number of parts of the STILT run.
   exit 1
fi

PART1=$1
PART2=$2
TOTPART=$3

if [[ "`which bsub`" == "" ]]; then
   echo no queueing command \(bsub\) found
   echo run e.g. on galactica
   exit 1
fi

[[ ! -d Runs.done ]] && mkdir Runs.done
for P in `seq $PART1 $PART2`; do
   echo -n submitting STILT part $P of ${TOTPART}"... "
   PF="`printf %2.2i $P`"
   bsub -M 2097152 -T 10 -J stilt_${PF} <<- EOD
		export STILT_PART=$P                 # careful: code down to EOD has tab indenting
		export STILT_TOTPART=$TOTPART
		R CMD BATCH --no-restore --no-save --slave stiltR/stilt.r stilt_${PF}.log
	EOD
done
