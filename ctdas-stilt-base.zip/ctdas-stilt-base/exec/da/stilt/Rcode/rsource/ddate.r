ddate<-function(yyyy,mm,dd, hr=0, mn=0, sc=0){

source("/projects/towers/src/rlib/julian.r")
source("/projects/towers/src/rlib/month.day.year.r")

#if (length(yyyy) >=3){
#tmp<-yyyy
#yyyy<-tmp[1]
#mm<-tmp[2]
#dd<-tmp[3]
#if (length(tmp) >=4) hr<-tmp[4]
#if (length(tmp) >=5) mn<-tmp[5]
#if (length(tmp) >=5) sc<-tmp[6]
#}

jday<-rep(NA, length(yyyy))
ndayyr<-rep(NA, length(yyyy))
for(tt in 1:length(yyyy)){
jday[tt]<-julian(mm[tt],dd[tt],yyyy[tt],c(1,1,yyyy[tt]))
ndayyr[tt]<-julian(12, 31, yyyy[tt], c(12,31,yyyy[tt]-1))
}

jout<-yyyy+(jday+(hr*3600+mn*60+sc)/(24*3600))/ndayyr


jout
}
