datelist<-function(startdate,enddate=startdate, adjday=F){

source("/projects/towers/src/rlib/julian.r")
source("/projects/towers/src/rlib/month.day.year.r")


startdate<-as.character(startdate)
enddate<-as.character(enddate)

yyyystart<-as.numeric(substr(startdate,1,4))
yyyyend<-as.numeric(substr(enddate,1,4))
mmstart<-as.numeric(substr(startdate,5,6))
mmend<-as.numeric(substr(enddate,5,6))
ddstart<-as.numeric(substr(startdate,7,8))
ddend<-as.numeric(substr(enddate,7,8))

julstart<-julian(mmstart,ddstart, yyyystart, origin=c(12, 31,yyyystart-1))
julend<-julian(mmend,ddend, yyyyend, origin=c(12, 31,yyyystart-1))


 jullist<-seq(julstart,julend,1)
if(adjday) jullist<-c(julstart-1,jullist,julend+1)
ymdlist<-month.day.year(jullist,origin=c(12,31,yyyystart-1))



yyyymmddlist<-rep(NA, length(jullist))
for (jj in 1:length(jullist)){
yyyytmp<-as.character(ymdlist$year[jj])
if(ymdlist$month[jj] >= 10) mmtmp<-as.character(ymdlist$month[jj])
if(ymdlist$month[jj] < 10) mmtmp<-paste('0',as.character(ymdlist$month[jj]),sep="")
if(ymdlist$day[jj] >= 10) ddtmp<-as.character(ymdlist$day[jj])
if(ymdlist$day[jj] < 10) ddtmp<-paste('0',as.character(ymdlist$day[jj]),sep="")

yyyymmddlist[jj]<-paste(yyyytmp,mmtmp,ddtmp,sep="")
}


yyyymmddlist

}
