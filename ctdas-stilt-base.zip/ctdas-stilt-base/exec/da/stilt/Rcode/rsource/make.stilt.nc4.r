# make.stilt.nc, 23 Feb 2010, A. Andrews
# modified 26 October 2010, A. Andrews remove cleanup
# modified 13 March 2012, M. Mountain - add horizconv field

make.stilt.nc4 <- function(ident,                                               # stilt identifier
                          ncname=paste("stilt",ident, ".nc", sep=""),           # stilt netCDF file name (created or appended)
                          origident=FALSE,                                      # include most accurate receptor agl,lat,lon,utctime fields 
                                                                                # before rounding for use in STILT
                          part=FALSE,                                           # include particle array
                          foot=FALSE,                                           # include foot
                          horizconv=FALSE,                                      # include results from horizontally convolving footprints with
                                                                                # fluxes for each particle and summing particle over time
                          avghorizconv=FALSE,                                   # include results from horizontally convolving footprints with
                                                                                # fluxes for each particle and summing particle over time, avg particles
                          runinfo=FALSE,                                        # text summary of run parameters
                          endpts=FALSE,                                         # trajectory endpoints
                          check=FALSE,                                          # output from Trajeccheck
                          init=FALSE,                                           # include init mixing ratio values
                          avginit=FALSE,                                        # include avginit mixing ratio value
                          footname=NULL,                                        # name of footprint to distinguish among multiple footprints -e.g. foot1, foot2, etc
                          horizconvname=NULL,                                   # name of horizontal convolve mixing ratio values (should reflect species
                                                                                # and source - e.g. co2horizconvCT, co2horizconvvul, etc)
                          avghorizconvname=NULL,                                # name of avg horizontal convolve mixing ratio (should reflect species
                                                                                # and source - e.g. co2avghorizconvCT, co2avghorizconvvul, etc)
                          initname=NULL,                                        # name of init mixing ratio values (should reflect species and source)
                                                                                # (e.g. co2initCT, co2initGV, coinitGV, etc)
                          avginitname=NULL,                                     # name of average init mixing ratio (should reflect species and source)
                                                                                # (e.g. co2avginitCT, co2avginitGV, coavginitGV, etc)
                          horizconvdatunits=NULL,                               # string indicating assigned units to horizconvdat
                          avghorizconvdatunits=NULL,                            # string indicating assigned units to avghorizconvdat
                          initdatunits=NULL,                                    # string indicating assigned units to initdat
                          avginitdatunits=NULL,                                 # string indicating assigned units to avginitdat
                          origidentdat=NULL,                                    # list of original receptor agl, lat, lon, utctime fields
                          origutctime.format=NULL,                              # string format of origutctime from receptor list 
                                                                                # e.g. '%Y-%m-%dT%H:%M:%S'
                          partdat=NULL,                                         # passed in R object (use getr by default)
                          footdat=NULL,                                         # passed in R object (use getr by default)
                          horizconvdat=NULL,                                    # passed in R object (use getr by default)
                          avghorizconvdat=NULL,                                 # passed in R object (use getr by default)      
                          runinfodat=NULL,                                      # passed in R object (use getr by default)
                          endptsdat=NULL,                                       # passed in R object (use getr by default)
                          checkdat=NULL,                                        # passed in R object (use getr by default)
                          initdat=NULL,                                         # passed in R object (use getr by default)
                          avginitdat=NULL,                                      # passed in R object (use getr by default)
                          partpath=NULL,                                        # location of particle file
                          checkpath=partpath,                                   # location of check file
                          footpath=paste(partpath, "footprints/", sep=""),      # location of footprint file
                          horizconvpath=paste(partpath, "convolve/", sep=""),   # location of horizontal convolve summarized results file
                          avghorizconvpath=paste(partpath, "convolve/", sep=""),# location of horizontal convolve summarized results file
                          endptspath=paste(partpath, "endpoints/", sep=""),     # location of endpts file
                          initpath=paste(partpath, "boundary/", sep=""),        # location of init file
                          avginitpath=paste(partpath, "boundary/", sep=""),     # location of avginit file
                          runinfopath=NULL,                                     # location of runinfo file
                          targetdir,                                            # destination directory
                          errorlog=paste("ncerrors",ident,".txt",sep=""),       # name of errorlog file; use NA to suppress
                          appendnc=FALSE,                                       # TRUE=>append an existing netCDF file,
                                                                                # FALSE=>create new netCDF file
                          plotfoot=F,
                          plotmeantrajec=F,
                          sourcepath=NULL) {                                            # begin function

#source required functions
  require("ncdf4")
  if(!exists('getr',mode='function') || !exists('id2info',mode='function')) {
    if (is.null(sourcepath)) {
      if (file.exists("stiltR"))
        sourcepath <- paste(getwd(), "/stiltR/", sep="")
      else if (file.exists("Rsc"))
        sourcepath <- paste(getwd(), "/Rsc/", sep="")
      else {
        stop('sourceall.r needs to be sourced, no sourcepath was provided as an argument,',
             ' and no stiltR or Rsc directory was found.')
      }
    }
    source(paste(sourcepath,"sourceall.r",sep=""))
  }

#Non Fatal Errors
  warns<-list()

#Check whether files exist and warn if not.

# modified: M. Trudeau, 26 Mar 2010
  if (part && is.null(partdat) && !existsr(ident,partpath)) { print(paste(".RData",ident, " not found. Exiting...",sep="")) ; return() }
  if (foot && is.null(footdat) && !existsr(paste("footr",ident,sep=""),footpath)) {warns$footnofile<-"NO FOOTPRINT FILE FOUND"; foot<-F}
  if (runinfo && is.null(runinfodat) && !existsr(paste("run.info",ident, sep=""),runinfopath)) { warns$runinfonofile<-"NO RUNINFO FILE FOUND"; runinfo<-F}
  if ( check && is.null(checkdat) && !existsr(paste("check",ident, sep=""),checkpath)) { warns$checknofile<-"NO CHECK FILE FOUND";check<-F }
  if (endpts && is.null(endptsdat) && !existsr(paste("end",ident, sep=""),endptspath))  {warns$endptsnofile<-"NO ENDPOINTS FILE FOUND";endpts<-F}

  if(!file.exists(targetdir)) {
    cat(sprintf("  Creating output path \"%s\".\n", targetdir))
    dir.create(targetdir,recursive=TRUE)
  }

  info<-id2info(ident)
  inittime<-ISOdatetime(info["yr"],info["mo"], info["dy"],info["hr"],0,0,tz="UTC")
  epoch <- ISOdatetime(2000,1,1,0,0,0,"UTC")


#DEFINE NCDF NCHAR DIMENTION FOR STRING VECTORS

  dimnchar   <- ncdim_def("nchar",   "", 1:500 )

#CREATE EMPTY LIST TO HOLD NCDF VARS

  vars<-list()
  outs<-list()


  nident.dim <-ncdim_def("nident","",vals=1:1,create_dimvar=F)
  vars$var.ident <- ncvar_def(name="ident",units="string",dim=list(dimnchar,nident.dim),
                                 missval="",longname="identifier string",prec="char",compression=9)

  outs$ident<-ident

  if (origident) {
    if(!is.null(origidentdat)){
      norigident.dim<-ncdim_def("norig","",vals=1:length(origidentdat[['agl']]),create_dimvar=F)
      vars$var.origagl<-ncvar_def(name="origagl",units="m",dim=list(norigident.dim),
                                  missval=-1e34,longname="original receptor height above ground level before rounding for STILT",
                                  compression=9)
      vars$var.origlat<-ncvar_def(name="origlat",units="degrees latitude where +/- indicates N/S",dim=list(norigident.dim),
                                  missval=-1e34,longname="original receptor latitude before rounding for STILT",
                                  compression=9)
      vars$var.origlon<-ncvar_def(name="origlon",units="degrees longitude where +/- indicates E/W",dim=list(norigident.dim),
                                  missval=-1e34,longname="original receptor longitude before rounding for STILT",
                                  compression=9)
      vars$var.origutctime<-ncvar_def(name="origutctime",units="UTC",dim=list(dimnchar,norigident.dim),
                                     missval="",longname="original receptor time in UTC before rounding for STILT",
                                     prec="char",compression=9)
      vars$var.origutctimeformat<-ncvar_def(name="origutctimeformat",units="none",dim=list(dimnchar,norigident.dim),
                                     missval="",longname="original receptor time (origutctime) format",
                                     prec="char",compression=9)

      outs$origagl <- as.numeric(origidentdat[['agl']])
      outs$origlat <- as.numeric(origidentdat[['lat']])
      outs$origlon <- as.numeric(origidentdat[['lon']])
      outs$origutctime <- as.character(origidentdat[['utctime']])
      outs$origutctimeformat <- as.character(origutctime.format)     
    }  else  warns$origidentnull<- "ORIGIDENTDAT IS EMPTY OR MISSING"
  }#end if origident

  if(part) {
    if(is.null(partdat) && existsr(ident, partpath)) partdat <-  getr(ident, partpath)
    if(!is.null(partdat)){

      partnames <-dimnames(partdat)[[2]]
      parttime <- NULL
      if ("time" %in% partnames) {
        #particle time provided in negative minutes
        parttime<-inittime + (partdat[,"time"]*60)  
      }
      if ("btime" %in% partnames) {
        #particle time provided in positive hours (negative implied)
        parttime<-inittime - (partdat[,"btime"]*3600)
      }
      if (is.null(parttime)) {
        parttime <- inittime + 1:dim(partdat)[1]
        warns$parttimenull <-
          "PARTICLE object does not have a (b)time column, assigning dummy values to parttime"
      }

#     nrowpart.dim<-ncdim_def("nrowpart","",vals=1:nrow(partdat),create_dimvar=F)
      ncolpart.dim<-ncdim_def("ncolpart","",vals=1:ncol(partdat),create_dimvar=F)
      npartnames.dim<-ncdim_def("npartnames","",vals=1:ncol(partdat),create_dimvar=F)

      vars$var.partnames<-ncvar_def(name="partnames",units="various",dim=list(dimnchar,npartnames.dim),
                                    missval="",longname="column names for particle array",prec="char",compression=9)
      partdate.vals <- as.numeric(difftime(parttime,epoch,units="days")) # subtract the epoch to make days-since
      partdate.dim <- ncdim_def("partdate","days since 2000-01-01 00:00:00 UTC",vals=partdate.vals)

      vars$var.part <- ncvar_def(name="part",units="various",dim=list(partdate.dim,ncolpart.dim),
                                 missval=-1e34,longname="stilt particle location array",compression=9)

      outs$partnames<-partnames
      outs$part<-partdat
    } else warns$partdatnull<- "PARTICLE FILE IS EMPTY"
  }#part

  if(foot){
    if(is.null(footdat)) footdat <-  getr(paste("footr",ident,sep=""), footpath)
    if(!is.null(footdat)){
      footlon<-as.numeric(dimnames(footdat)[[2]])
      footlat<-as.numeric(dimnames(footdat)[[1]])
      foothr<-as.numeric(dimnames(footdat)[[3]])
      foottime<-inittime-foothr*3600

      footlon.dim <- ncdim_def(paste(footname,'lon',sep=''),"degrees longitude where +/- indicates E/W",vals=footlon)
      footlat.dim <- ncdim_def(paste(footname,'lat',sep=''),"degrees latitude where +/- indicates N/S",vals=footlat)
      footdate.vals <- as.numeric(difftime(foottime,epoch,units="days")) # subtract the epoch to make days-since
      footdate.dim <- ncdim_def(paste(footname,'date',sep=''),"days since 2000-01-01 00:00:00 UTC",vals=footdate.vals)
      vars[[paste('var.',footname,sep='')]] <- ncvar_def(name=footname,units="ppm per (micromol m-2 s-1)",dim=list(footlat.dim,footlon.dim,footdate.dim),
                                    missval=-1e34,longname="stilt footprint",compression=9)
      vars[[paste('var.',footname,'hr',sep='')]] <- ncvar_def(name=paste(footname,'hr',sep=''),units="hours)",dim=list(footdate.dim),
                                    missval=-1e34,longname="hours back for stilt footprint",compression=9)

      outs[[footname]] <- footdat
      outs[[paste(footname,'hr',sep='')]] <- foothr
      if(plotfoot){
	library(fields)
	library(maps)

        print(paste("Saving... ", targetdir, "foot", ident, ".pdf", sep=""))

	pdf(file=paste(targetdir,"foot",ident,".pdf",sep=""))
	xfoot<-apply(footdat, MARGIN=c(1,2), FUN=sum)
	temp<-log10(xfoot)
        temp[!is.finite(temp)]<-NA
        image.plot(x=footlon ,y=footlat,z=t(temp), col=c("#FFFFFF",tim.colors(64)),xlab="",ylab="",  zlim=c(-10,0), xlim=c(-180,-40),ylim=c(25,80))
        box()
        map("state", add=T)
        map("world",add=T)
        title(ident)
        dev.off()
      }
    } else warns$footdatnull<- "FOOTPRINT FILE IS EMPTY"

  }#foot

  if(horizconv){
    if (is.null(horizconvname)) {
        horizconvname <- 'horizconv'
        warns$horizconvnamenull <- paste("HORIZCONV object does not have an assigned name ",
                                    "designating unique species and source, ",
                                    "assigning dummy name to horizconvname",sep='')
    }
    if (is.null(horizconvdatunits)) {
        horizconvdatunits <- 'unknown'
        warns$horizconvdatunitsnull <- paste("HORIZCONV object does not have assigned units ",
                                    "assigning dummy units to horizconvdatunits",sep='')
    }
    if(!is.null(horizconvdat)){
      horizconvdatnames <-dimnames(horizconvdat)[[2]]

      ncol.dim<-ncdim_def(paste("ncol",horizconvname,sep=""),"",vals=1:ncol(horizconvdat),create_dimvar=F)
      nrow.dim<-ncdim_def(paste("nrow",horizconvname,sep=""),"",vals=1:nrow(horizconvdat),create_dimvar=F)

      vars[[paste('var.',horizconvname,sep='')]] <- ncvar_def(name=horizconvname,units=horizconvdatunits,dim=list(nrow.dim,ncol.dim),
                                 missval=-1e34,longname="matrix containing horizontally convolved mixing ratios of particles and associated particle index value",compression=9)

      vars[[paste('var.',horizconvname,'names',sep='')]] <- ncvar_def(name=paste(horizconvname,'names',sep=''),units="none",dim=list(dimnchar,ncol.dim),
                                    missval="",longname="column names of associated horizontally convolved results matrix",prec="char",compression=9)

      outs[[horizconvname]] <- horizconvdat
      outs[[paste(horizconvname,'names',sep='')]] <- horizconvdatnames
    } else warns$horizconvdatnull<- "HORIZONTAL CONVOLVE SUMMARY RESULTS NOT FOUND"    
  }#horizconv

  if(avghorizconv){
    if (is.null(avghorizconvname)) {
        avghorizconvname <- 'avghorizconv'
        warns$avghorizconvnamenull <- paste("AVGHORIZCONV object does not have an assigned name ",
                                    "designating unique species and source, ",
                                    "assigning dummy name to avghorizconvname",sep='')
    }
    if (is.null(avghorizconvdatunits)) {
        avghorizconvdatunits <- 'unknown'
        warns$avghorizconvdatunitsnull <- paste("AVGHORIZCONV object does not have assigned units ",
                                    "assigning dummy units to avghorizconvdatunits",sep='')
    }
    if(!is.null(avghorizconvdat)){
      n.dim<-ncdim_def(paste("n",avghorizconvname,sep=""),"",vals=1:length(avghorizconvdat),create_dimvar=F)

      vars[[paste('var.',avghorizconvname,sep='')]] <- ncvar_def(name=avghorizconvname,units=avghorizconvdatunits,dim=list(n.dim),
                                 missval=-1e34,longname="average horizontally convolved mixing ratio of all particles",compression=9)

      outs[[avghorizconvname]] <- avghorizconvdat
    } else warns$avghorizconvdatnull<- "AVGHORIZONTAL CONVOLVE SUMMARY RESULTS NOT FOUND"    
  }#avghorizconv

  if(check) {
    if(is.null(checkdat)) checkdat <-  getr(paste("check",ident,sep=""), checkpath)
    if(!is.null(checkdat)){
      checkbasic<-checkdat$basic
      checkbasicnames<-names(checkdat$basic)

      if(!is.null(checkbasic) & !is.null(checkbasicnames)){
        ncheckbasic.dim<-ncdim_def("ncheckbasic","",vals=1:length(checkbasic),create_dimvar=F)

        vars$var.checkbasic <- ncvar_def(name="checkbasic",units="various",dim=list(ncheckbasic.dim),
                                             missval=-1e34,longname="basic output from Trajeccheck()",compression=9)

        vars$var.checkbasicnames<-ncvar_def(name="checkbasicnames",units="various",dim=list(dimnchar,ncheckbasic.dim),
                                             missval="",longname="names for checkbasic 1D array", prec="char",compression=9)
        outs$checkbasicnames<-checkbasicnames
        outs$checkbasic<-checkbasic

      } else  warns$checkbasicnull<- "CHECKDAT$BASIC IS EMPTY OR NAMES ARE MISSING"

      checksum<-checkdat$summary
      checksumnames<-dimnames(checkdat$summary)[[2]]

      if(!is.null(checksum) & !is.null(checksumnames)){

        checksumtime<-inittime+checksum[,"time"]*60
 

        checksumdate.vals <- as.numeric(difftime(checksumtime,epoch,units="days")) # subtract the epoch to make days-since
        checksumdate.dim <- ncdim_def("checksumdate","days since 2000-01-01 00:00:00 UTC",vals=checksumdate.vals)
        ncolchecksum.dim<-ncdim_def("ncolchecksum","",vals=1:ncol(checksum),create_dimvar=F)
 
       vars$var.checksumnames<-ncvar_def(name="checksumnames",units="various",dim=list(dimnchar,ncolchecksum.dim),
                                            missval="",longname="column names for checksum array",prec="char",compression=9)

        vars$var.checksum <- ncvar_def(name="checksum",units="various",dim=list(checksumdate.dim,ncolchecksum.dim),
                                          missval=-1e34,longname="checksum array",compression=9)
        outs$checksumnames<-checksumnames
        outs$checksum<-checksum

        if(plotmeantrajec){
          errorbar<-function(xx,yy,xunc=NULL,yunc=NULL,color=1,ltype=1,lwidth=1,xbar=NULL,ybar=NULL){

            if (!is.null(xunc)) segments(xx+xunc,yy,xx-xunc,yy, col=color,lty=ltype,lwd=lwidth)
            if (!is.null(yunc)) segments(xx,yy+yunc,xx,yy-yunc, col=color,lty=ltype,lwd=lwidth)
            if(!is.null(xbar)&!is.null(xunc)){
              segments(xx-xunc,yy-xbar,xx-xunc,yy+xbar, col=color,lty=ltype,lwd=lwidth)
              segments(xx+xunc,yy-xbar,xx+xunc,yy+xbar, col=color,lty=ltype,lwd=lwidth)
            }
            if(!is.null(ybar)&!is.null(yunc)){
              segments(xx-ybar,yy-yunc,xx+ybar,yy-yunc, col=color,lty=ltype,lwd=lwidth)
              segments(xx-ybar,yy+yunc,xx+ybar,yy+yunc, col=color,lty=ltype,lwd=lwidth)
            }
          } #errorbar

          print(paste("Saving... ", targetdir, "meantrajec", ident, ".pdf", sep=""))

          pdf(file=paste(targetdir,"meantrajec",ident,".pdf",sep=""))
          library(maps)
          plot(checksum[,"mlon"],checksum[,"mlat"],xlim=c(-180,-50),ylim=c(10,70),xlab="",ylab="", type="n")
          errorbar(checksum[,"mlon"],checksum[,"mlat"],xunc=checksum[,"slon"],yunc=checksum[,"slat"],col=8,xbar=0,ybar=0)
          points(checksum[,"mlon"],checksum[,"mlat"], type="l",lwd=3)
          map(add=T)
          map("state", add=T)
          title(ident)
          dev.off()
	} #if plotmeantrajec
      } else  warns$checksumnull<- "CHECKDAT$SUM IS EMPTY OR NAMES ARE MISSING"

  

    } else warns$checkdatnull<- "CHECKDAT IS EMPTY"

  }#check

  if(endpts){
    if(is.null(endptsdat)) endptsdat <- data.matrix(getr(paste("end",ident,sep=""), endptspath))
    if(!is.null(endptsdat)){

      endptsnames <- dimnames(endptsdat)[[2]]

      endptstime <- NULL
      if ("time" %in% endptsnames) {
        #particle time provided in negative minutes "time"
        endptstime<-inittime + (endptsdat[,"time"]*60)
      }
      if ("btime" %in% endptsnames) {
        #particle time provided in positive hours (negative implied) "btime"
        endptstime<-inittime - (endptsdat[,"btime"]*3600)
      }
      if (is.null(endptstime)) {
        endptstime <- inittime + 1:dim(endptsdat)[1]
        warns$endptstimenull <-
          "ENDPTS object does not have a (b)time column, assigning dummy values to endptstime"
      }

      nrowendpts.dim<-ncdim_def("nrowendpts","",vals=1:nrow(endptsdat),create_dimvar=F)

      endptsdate.vals <- as.numeric(difftime(endptstime,epoch,units="days")) # subtract the epoch to make days-since
      endptsdate.dim <- ncdim_def("endptsdate","days since 2000-01-01 00:00:00 UTC",vals=endptsdate.vals)

      ncolendpts.dim<-ncdim_def("ncolendpts","",vals=1:ncol(endptsdat),create_dimvar=F)
      vars$var.endpts <- ncvar_def(name="endpts",units="various",dim=list(endptsdate.dim,ncolendpts.dim),
                                      missval=-1e34,longname="stilt endpoint matrix",compression=9)
      vars$var.endptsnames<-ncvar_def(name="endptsnames",units="none",dim=list(dimnchar,ncolendpts.dim),
                                         missval="",longname="column names for endpoints matrix", prec="char",compression=9)

      outs$endpts<-endptsdat
      outs$endptsnames<-endptsnames
    }  else  warns$endptsnull<- "ENDPTS IS EMPTY OR NAMES ARE MISSING"

  }#endpts

  if(runinfo){
    if(is.null(runinfodat)) runinfodat <- getr(paste("run.info",ident,sep=""), runinfopath)
    if(!is.null(runinfodat)){

      runinfonames<-dimnames(runinfodat)[[2]]


      nruninfo.dim<-ncdim_def("nruninfo","",vals=1:(dim(runinfodat)[2]),create_dimvar=T)
      vars$var.runinfonames<-ncvar_def(name="runinfonames",units="various",dim=list(dimnchar,nruninfo.dim),
                                          missval="",longname="names for runinfo array",prec="char",compression=9)
      vars$var.runinfo<-ncvar_def(name="runinfo",units="various",dim=list(dimnchar,nruninfo.dim),
                                     missval="",longname="runinfo array",prec="char",compression=9)

      outs$runinfonames<-runinfonames
      outs$runinfo<-runinfodat
    }  else  warns$runinfonull<- "RUNINFO IS EMPTY OR NAMES ARE MISSING"
  }#runinfo

  if (init) {
    if (is.null(initname)) {
        initname <- 'init'
        warns$initnamenull <- paste("INIT object does not have an assigned name ",
                                    "designating unique species and source, ",
                                    "assigning dummy name to initname",sep='')
    }
    if (is.null(initdatunits)) {
        initdatunits <- 'unknown'
        warns$initdatunitsnull <- paste("INIT object does not have assigned units ",
                                    "assigning dummy units to initdatunits",sep='')
    }
    if (!is.null(initdat)) {
      initdatnames <- dimnames(initdat)[[2]]
      nrow.dim <- ncdim_def(paste("nrow",initname,sep=""),"",vals=1:nrow(initdat),create_dimvar=F)
      ncol.dim <- ncdim_def(paste("ncol",initname,sep=""),"",vals=1:ncol(initdat),create_dimvar=F)

      vars[[paste('var.',initname,sep='')]] <- ncvar_def(name=initname,units=initdatunits,dim=list(nrow.dim,ncol.dim),
                                   missval=-1e34,longname="matrix containing initial mixing ratio values of particles and associated particle index value",compression=9)

      vars[[paste('var.',initname,'names',sep='')]] <- ncvar_def(name=paste(initname,'names',sep=''),units='none',dim=list(dimnchar,ncol.dim),
                                   missval="",longname="column names of associated init data matrix",prec="char",compression=9)

      outs[[initname]] <- initdat
      outs[[paste(initname,'names',sep='')]] <- initdatnames

    }else{warns$initdatnull<- "INITDAT IS EMPTY OR NAMES ARE MISSING"}
  }#init

  if (avginit) {
    if (is.null(avginitname)) {
        avginitname <- 'avginit'
        warns$avginitnamenull <- paste("AVGINIT object does not have an assigned name ",
                                    "designating unique species and source, ",
                                    "assigning dummy name to avginitname",sep='')
    }
    if (is.null(avginitdatunits)) {
        avginitdatunits <- 'unknown'
        warns$avginitdatunitsnull <- paste("AVGINIT object does not have assigned units ",
                                    "assigning dummy units to avginitdatunits",sep='')
    }
    if (!is.null(avginitdat)) {
      n.dim <- ncdim_def(paste("n",avginitname,sep=""),"",vals=1:length(avginitdat),create_dimvar=F)

      vars[[paste('var.',avginitname,sep='')]] <- ncvar_def(name=avginitname,units=avginitdatunits,dim=list(n.dim),
                                   missval=-1e34,longname="average initial mixing ratio value of all particles",compression=9)

      outs[[avginitname]] <- avginitdat

    }else{warns$avginitdatnull<- "AVGINITDAT IS EMPTY OR NAMES ARE MISSING"}
  }#avginit

  ncnameout<-paste(targetdir,ncname,sep="")

  varnames<-names(vars)
  outnames<-matrix(unlist(strsplit(names(vars),"var.")),ncol=2, byrow=T)[,2]

  if (appendnc && file.exists(ncnameout)) {
    #Append existing NCDF output file and write variable to file.

    #retrieve data from existing netCDF file before its overwritten
    filenc <- nc_open(ncnameout, write=TRUE)
    oldnames <- names(filenc$var)
    cat('netCDF variable names in existing file = ',oldnames,'\n')

    #find variables that are missing in newest version of file
    for (i in 1:length(outnames)) {
      if (any(oldnames == outnames[i])) {
        if (outnames[i] == 'ident') {
          cat(' Skipping: variable = ', outnames[i],'is already in netCDF file\n')
        }else{
          stop('Do not overwrite: Variable = ', outnames[i],'is already in netCDF file\n')
        }
      }else{
        #variable is not in file, append to file
        cat('Attempt to append file with variable = ', outnames[i],'\n')

        #modify file handle to contain new ncvar4 variable (data is junk)
        filenc <- ncvar_add(filenc, vars[[varnames[i]]]) 

        #close file handle to save ncvar4 changes and reopen to add data
        #(ncvar_put won't work without closing and reopening)
        nc_close(filenc)
        filenc <- nc_open(ncnameout, write=TRUE)
        ncvar_put(filenc, vars[[varnames[i]]],outs[[outnames[i]]])
      }
    }#end for i
    #close file
    nc_close(filenc)

  }else{
    #Create new NCDF output file and write variable to file.
    ncf <- nc_create(ncnameout,vars=vars)

    for (nn in 1:length(varnames)) {
      cat('Attempting to write netCDF data for variable = ',varnames[nn],'\n')
      ncvar_put(ncf, vars[[varnames[nn]]],outs[[outnames[nn]]])
    }

    nc_close(ncf)
  }#end if appendnc

#If warnings are present, write to errorlog file

  errorlogout<-paste(targetdir,errorlog,sep="")
  if(!is.null(names(warns)) && !is.na(errorlog)) {
    do.append=FALSE
    for(ww in names(warns)) {
      cat(paste(ww,': ',warns[[ww]],'\n',sep=''),file=errorlogout, append=do.append)
      do.append=TRUE
    }
  } #if warnings

  warns
  
} #end function
