# Time-stamp: <harmattan.cmdl.noaa.gov:/local/ct/tools/R/load.ncdf.r - 12 Dec 2008 (Fri) 11:03:36 MST>
#modified Oct 2010 AEA:  handle gzipped files
#Make all letters lowercase, replace "." with "_"
#Add "hours since" on Oct 3, 2011 by Huilin Chen for Campbell's OCS fluxes
load.ncdf <-function(ncname,lowercase=TRUE,dims=TRUE,attribs=NULL,vars=NULL,gz=FALSE) {#load.ncdf
  
  	library(ncdf)

	#gz file?
	if(gz) {
		systime<-as.numeric(Sys.time())
		tmppath<-paste("/projects/towers/tmp",systime,"/",sep="")
		dir.create(tmppath)
		system(paste("gunzip -c ",ncname," > ",tmppath,"nctmp.nc",sep=""))
		ncname<-paste(tmppath,"nctmp.nc", sep="")
		#system(paste("chmod a+w /projects/towers/tmp/nctmp.nc")
		system(paste("chmod a+w ",ncname,sep=""))
	}

  	retval <- list()
  	nc <- open.ncdf(ncname)
  	i <- 0

  	# variables
  	if(is.null(vars)) {vars <- names(nc$var)}

  	for(var in vars) {#loop var
    		if(! var %in% names(nc$var)) {
      			warning(sprintf("variable \"%s\" not in file \"%s\".",var,ncname))
      			next
    		}
    		#    print(var)
    		i <- i+1
    		if(nc$var[[var]]$ndims > 0) {
      		retval[[i]] <- get.var.ncdf(nc,var)
    		} else {  # empty variable (present in nc files from ORNL)
     	 		retval[[i]] <- NA
    		}
    		names(retval)[i] <- gsub('_','.',var)
	}#end loop var

  	# dimensions
  	if(dims) {
   		retval$dim <- nc$dim
    		for (d in names(nc$dim)) {
      			ddot <- gsub('_','.',d)
      			retval[[ddot]] <- nc$dim[[d]]$vals
      
      			#DAYS since
      			if(length(grep("^DAYS since", nc$dim[[d]]$units,ignore.case=TRUE))==1) {
        			# length of string is a bad parsing heuristic, but works
        			# for everything so far.
        			#     21 chars if "days since 1900-01-01"
        			#     19 chars if "days since 1900-1-1"
        			if(nchar(nc$dim[[d]]$units)==21| nchar(nc$dim[[d]]$units)==19) {
          				retval[[ddot]] <- strptime(substr(nc$dim[[d]]$units,11,nchar(nc$dim[[d]]$units)),
                                		"%Y-%m-%d", tz="UTC") + nc$dim[[d]]$vals*86400
        			} else {
          			retval[[ddot]] <- strptime(substr(nc$dim[[d]]$units,11,nchar(nc$dim[[d]]$units)),
                                     "%Y-%m-%d %H:%M:%s", tz="UTC") + nc$dim[[d]]$vals*86400
        			}
      			}#if "DAYS since"
		
      			#SECONDS since
      			if(length(grep("^SECONDS since", nc$dim[[d]]$units,ignore.case=TRUE))==1) {
        			if(nchar(nc$dim[[d]]$units)==24) {
          				retval[[ddot]] <- strptime(substr(nc$dim[[d]]$units,15,nchar(nc$dim[[d]]$units)),
                                     	"%Y-%m-%d", tz="UTC") + nc$dim[[d]]$vals
          				attributes(retval[[ddot]])$tzone <- "UTC" # UTC tzone is a presumption
        			} else {
          				retval[[ddot]] <- strptime(substr(nc$dim[[d]]$units,15,nchar(nc$dim[[d]]$units)),
                                     		"%Y-%m-%d %H:%M:%s", tz="UTC") + nc$dim[[d]]$vals
          				attributes(retval[[ddot]])$tzone <- "UTC" # UTC tzone is a presumption
        			}
      			}#if "SECONDS since"
      
      			#decimal date
      			if(length(grep("^decimal date", nc$dim[[d]]$units,ignore.case=TRUE))==1) {
        			retval[[ddot]] <- decimal.to.POSIX(nc$dim[[d]]$vals)
        			attributes(retval[[ddot]])$tzone <- "UTC" # UTC tzone is a presumption
      			}
      
     		 	#hours since 
      			if(length(grep("hours since", nc$dim[[d]]$units,ignore.case=TRUE))==1) { 		
				retval[[ddot]] <- strptime(substr(nc$dim[[d]]$units,13,nchar(nc$dim[[d]]$units)),
                                     "%d-%b-%Y", tz="UTC") + nc$dim[[d]]$vals*3600
          			attributes(retval[[ddot]])$tzone <- "UTC" # UTC tzone is a presumption      
      			}#if hours since
    		}#loop d
  	}#if dim == TRUE
  
  	for (att in attribs) {
    		attributes(retval)[[att]] <- NULL
    		att.val <- att.get.ncdf(nc,0,att)
    		if(att.val$hasatt) {attributes(retval)[[gsub('_','.',att)]] <- att.val$value} 
  	}
  
  	close.ncdf(nc)
  
  	if(gz) {system(paste("rm -f",ncname));system(paste("rm -Rf ",tmppath))}
  	if(lowercase) {names(retval) <- tolower(names(retval))}
  
  	return(retval)
	
}#load.ncdf
