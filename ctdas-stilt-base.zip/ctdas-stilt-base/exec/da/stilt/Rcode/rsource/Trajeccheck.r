Trajeccheck <- function(ident,part=NULL, partpath="./", return=T,
                        outpath="./", outname=paste("check",ident,sep=""),
                        read.r=TRUE,write.r=TRUE,read.nc=!read.r,write.nc=!write.r) {
#Read in a particle file

  if(is.null(part)){   #when object wasn't passed on
#Check if object exists
    if (read.r) {
      if (existsr(ident,partpath)) {
        print(paste("Trajeccheck(): starting with ident=",ident,sep="")) #found object
        part<-getr(ident,partpath) #get it
      } else {#if not there, break out of function, return NA's
        print(paste("Trajeccheck(): object=",partpath,".RData",ident," NOT FOUND",sep=""))
      } #if exists or not
    }
    if (read.nc && is.null(part)) {
      ncname <- paste(partpath,"stilt",ident,".nc",sep="")
      if (file.exists(ncname)) {
        partlist <- load.ncdf4(ncname=ncname,dims=FALSE)
        part <- partlist$part
        if (!is.null(part)) dimnames(part) <- list(NULL,partlist$partnames)
      } else {
        print(paste("Trajeccheck(): ncfile=",ncname," NOT FOUND",sep=""))
      }
    }
    if(is.null(part)) return()
  } #if(!is.null(part)){

####  REPORT 1:  BASIC CHARACTERISTICS OF PARTICLE ARRAY

#how many particles at start of run
  npart<-max(part[,"index"])
#how many timesteps
  utime<-unique(part[,"time"])									 
  ntsteps<-length(utime)
#check, how many rows
  drow<-nrow(part)
  tmin<-min(part[,"time"])
  npartlast<-sum(part[,"time"]==tmin)

  report1<-c(drow,ntsteps,tmin,npart,npartlast)
  names(report1)<-c("nrow","ntsteps","tmin","npart","npartend")

####  REPORT 2:  QUASI-HOURLY INFORMATION ABOUT N PARTICLES REMAINING

#use tapply to find n particles for each timestep
  npart<-tapply(!is.na(part[,"index"]), part[,"time"], FUN=sum)
  utime<-as.numeric(names(npart))
  mlon<-tapply(part[,"lon"], part[,"time"], FUN=mean)
  mlat<-tapply(part[,"lat"], part[,"time"], FUN=mean)
  magl<-tapply(part[,"agl"], part[,"time"], FUN=mean)
  masl<-tapply(part[,"agl"]+part[,"grdht"], part[,"time"], FUN=mean)
  mpres<-tapply(part[,"pres"], part[,"time"], FUN=mean)
    
  slon<-sqrt(tapply(part[,"lon"], part[,"time"], FUN=var))
  slat<-sqrt(tapply(part[,"lat"], part[,"time"], FUN=var))
  sagl<-sqrt(tapply(part[,"agl"], part[,"time"], FUN=var))
  sasl<-sqrt(tapply(part[,"agl"]+part[,"grdht"], part[,"time"], FUN=var))
  spres<-tapply(part[,"pres"], part[,"time"], FUN=mean)
  

#Nifty function findInterval used to find indexes for times closest to the hour
#then subset output.

  hrvec<-seq(-240,0,1)
  ixhr<-findInterval( hrvec, utime/60)
 
  report2<-cbind(utime,npart,mlat,slat,mlon,slon,magl,sagl,masl,sasl,mpres,spres)[unique(ixhr),,drop=FALSE]
  dimnames(report2)<-list(NULL,c("time","npart","mlat","slat","mlon","slon","magl","sagl","masl","sasl","mpres","spres"))

  out<-list(report1,report2)
  names(out)<-c("basic","summary")

  # write output to R and/or ncdf; note that if outpath=partpath, will overwrite existing ncdf file
  if (write.r && !is.null(outname)) assignr(outname, out, path = outpath)
  if (write.nc) make.stilt.nc4(ident=ident,ncname=paste("stilt",ident,".nc",sep=""),
                              targetdir=outpath,errorlog=NA,plotmeantraj=FALSE, appendnc=FALSE,
                              part=TRUE, partdat=part, check=TRUE, checkdat=out)
  if (return) return(out)

} # function
