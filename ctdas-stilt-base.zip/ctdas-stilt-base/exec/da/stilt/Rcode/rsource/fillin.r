fillin<-function(x1, y1, x2 = x1, rule = 1., na.rm=T)
{
	zz <- rep(NA, length(x2))
	ick <- !is.na(x1) & !is.na(y1)
	ack <- approx(x1[ick], y1[ick], xout = x2[!is.na(x2)], rule = rule)$y
	zz[!is.na(x2)] <- ack
	
	nax1<-is.na(x1)
	nay1<-is.na(y1)

       nax1y1<-as.numeric(nax1|nay1)

       navec<-approx(x1,nax1y1,x2, rule=1)$y
       if(na.rm==F) zz[navec!=0]<-NA
       zz
}


