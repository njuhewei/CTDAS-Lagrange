.. _mysettings:

Personal Settings Module
========================

.. automodule:: da.analysis.mysettings
