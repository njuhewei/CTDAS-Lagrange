.. _statevector:

The Observation Operator Object
==========================================

.. automodule:: da.baseclasses.observationoperator




