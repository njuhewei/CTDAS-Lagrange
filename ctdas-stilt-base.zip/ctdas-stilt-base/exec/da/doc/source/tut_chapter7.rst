.. _tut_chapter7:

Chapter 7: Adding a new type of observations 
----------------------------------------------------
To be completed...
