.. _tut_chapter6:

Chapter 6: Changing the covariance structure
----------------------------------------------------
To be completed...
