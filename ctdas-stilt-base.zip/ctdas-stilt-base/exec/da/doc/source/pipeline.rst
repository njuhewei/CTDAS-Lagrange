.. _pipeline:

The Inverse Pipeline
====================

.. automodule:: da.tools.pipeline

