.. _optimizer:

The Optimizer Object
==========================================

.. automodule:: da.baseclasses.optimizer




