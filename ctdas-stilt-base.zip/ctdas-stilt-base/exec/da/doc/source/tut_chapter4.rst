.. _tut_chapter4:

Chapter 4: Adding more observations 
----------------------------------------------------
To be completed...
